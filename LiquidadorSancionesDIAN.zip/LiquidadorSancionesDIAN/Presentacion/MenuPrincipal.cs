﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class MenuPrincipal
    {
        public void Menu()
        {
            int op;
            do
            {
                Console.Clear();
                Console.SetCursorPosition(10, 3); Console.Write("MENÚ PRINCIPAL");
                Console.SetCursorPosition(10, 5); Console.Write("1. Gestión de Sanciones Aduaneras");
                Console.SetCursorPosition(10, 7); Console.Write("0. Salir");
                Console.SetCursorPosition(10, 9); Console.Write("Opción: ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        new VistaSancion().MenuSancion();
                        break;
                    case 0:
                        return;
                    default:
                        break;
                }
            } while (true);
        }
    }
}
