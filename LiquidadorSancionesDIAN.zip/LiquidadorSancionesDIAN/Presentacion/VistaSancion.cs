﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class VistaSancion
    {
        ServicioSancion servicio;

        public VistaSancion()
        {
            servicio = new ServicioSancion();
        }

        public void MenuSancion()
        {
            int op;
            do
            {
                Console.Clear();
                Console.SetCursorPosition(10, 3); Console.Write("GESTIÓN DE SANCIONES ADUANERAS");
                Console.SetCursorPosition(10, 5); Console.Write("1. Guardar");
                Console.SetCursorPosition(10, 7); Console.Write("2. Consultar");
                Console.SetCursorPosition(10, 9); Console.Write("3. Eliminar");
                Console.SetCursorPosition(10, 11); Console.Write("0. Salir");
                Console.SetCursorPosition(10, 13); Console.Write("Opción: ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        Guardar();
                        break;
                    case 2:
                        Consultar();
                        break;
                    case 3:
                        Eliminar();
                        break;
                    case 0:
                        return;
                    default:
                        break;
                }
            } while (true);
        }

        private void Guardar()
        {
            try
            {
                DeclaracionSancionada declaracion = new DeclaracionSancionada();

                Console.Clear();
                Console.SetCursorPosition(10, 3); Console.Write("REGISTRAR DECLARACIÓN SANCIONADA");

                Console.SetCursorPosition(10, 5); Console.Write("NIT: ");
                declaracion.NIT = Console.ReadLine();

                Console.SetCursorPosition(10, 7); Console.Write("Razón social: ");
                declaracion.RazonSocial = Console.ReadLine();

                Console.SetCursorPosition(10, 9); Console.Write("Número declaración importación: ");
                declaracion.NumeroDeclaracionImportacion = Console.ReadLine();

                Console.SetCursorPosition(10, 11); Console.Write("Días hábiles transcurridos: ");
                declaracion.DiasHabilesTranscurridos = int.Parse(Console.ReadLine());

                Console.SetCursorPosition(10, 13); Console.Write("Tipo de infracción (1.Leve 2.Grave 3.Gravísima 4.Contrabando): ");
                int tipo = int.Parse(Console.ReadLine());

                switch (tipo)
                {
                    case 1:
                        declaracion.TipoInfraccion = new InfraccionLeve();
                        break;
                    case 2:
                        declaracion.TipoInfraccion = new InfraccionGrave();
                        break;
                    case 3:
                        declaracion.TipoInfraccion = new InfraccionGravisima();
                        break;
                    case 4:
                        declaracion.TipoInfraccion = new InfraccionContrabando();
                        break;
                    default:
                        Console.SetCursorPosition(10, 15); Console.Write("Tipo de infracción no válido.");
                        Console.ReadKey();
                        return;
                }

                var mensaje = servicio.Guardar(declaracion);

                Console.Clear();
                Console.SetCursorPosition(10, 7); Console.Write(mensaje);
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.SetCursorPosition(10, 17); Console.Write($"Error: {ex.Message}");
                Console.ReadKey();
            }

        }
        private void Consultar()
        {
            Console.Clear();
            MostrarTabla();
            Console.SetCursorPosition(5, servicio.Consultar().Count + 8); Console.Write("Presione una tecla para continuar...");
            Console.ReadKey();
        }

        private void MostrarTabla()
        {
            Console.SetCursorPosition(5, 3); Console.Write("Expediente");
            Console.SetCursorPosition(18, 3); Console.Write("NIT");
            Console.SetCursorPosition(30, 3); Console.Write("Razón Social");
            Console.SetCursorPosition(48, 3); Console.Write("Infracción");
            Console.SetCursorPosition(62, 3); Console.Write("Entidad Recaudadora");
            Console.SetCursorPosition(84, 3); Console.Write("V.Base");
            Console.SetCursorPosition(95, 3); Console.Write("Ajuste");
            Console.SetCursorPosition(103, 3); Console.Write("V.Pagar");

            int fila = 5;
            foreach (var item in servicio.Consultar())
            {
                Console.SetCursorPosition(5, fila); Console.Write(item.NumeroExpediente);
                Console.SetCursorPosition(18, fila); Console.Write(item.NIT);
                Console.SetCursorPosition(30, fila); Console.Write(item.RazonSocial);
                Console.SetCursorPosition(48, fila); Console.Write(item.TipoInfraccion.GetType().Name);
                Console.SetCursorPosition(62, fila); Console.Write(item.EntidadRecaudadora);
                Console.SetCursorPosition(84, fila); Console.Write(item.ValorBase.ToString("C0"));
                Console.SetCursorPosition(95, fila); Console.Write(item.Ajuste.ToString("P0"));
                Console.SetCursorPosition(103, fila); Console.Write(item.ValorAPagar.ToString("C0"));
                fila++;
            }
        }

        private void Eliminar()
        {
            try
            {
                Console.Clear();
                Console.SetCursorPosition(5, 1); Console.Write("LISTA ANTES DE ELIMINAR:");
                MostrarTabla();

                int filaLibre = servicio.Consultar().Count + 6;
                Console.SetCursorPosition(5, filaLibre); Console.Write("Número de expediente a eliminar: ");
                string numero = Console.ReadLine();

                var declaracion = servicio.BuscarPorExpediente(numero);

                if (declaracion == null)
                {
                    Console.SetCursorPosition(5, filaLibre + 2); Console.Write("No existe un expediente con ese número.");
                    Console.ReadKey();
                    return;
                }

                bool eliminado = servicio.Eliminar(declaracion);

                Console.Clear();
                Console.SetCursorPosition(5, 1);
                Console.Write(eliminado ? "Expediente eliminado. LISTA DESPUÉS DE ELIMINAR:" : "No se pudo eliminar el expediente.");
                MostrarTabla();

                Console.SetCursorPosition(5, servicio.Consultar().Count + 8); Console.Write("Presione una tecla para continuar...");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.SetCursorPosition(5, 20); Console.Write($"Error: {ex.Message}");
                Console.ReadKey();
            }
        }

    }

}