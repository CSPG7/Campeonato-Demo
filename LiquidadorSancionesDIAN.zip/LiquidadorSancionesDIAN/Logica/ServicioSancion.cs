﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class ServicioSancion : IServicio<DeclaracionSancionada>
    {
        private List<DeclaracionSancionada> declaraciones;
        private int contadorExpediente;

        public ServicioSancion()
        {
            declaraciones = new List<DeclaracionSancionada>();
            contadorExpediente = 0;
        }

        public string Guardar(DeclaracionSancionada declaracion)
        {
            try
            {
                if (declaracion == null)
                    return "Declaración no válida.";

                if (string.IsNullOrEmpty(declaracion.NIT) || string.IsNullOrEmpty(declaracion.RazonSocial))
                    return "El NIT y la razón social son obligatorios.";

                if (declaracion.TipoInfraccion == null)
                    return "Debe indicar el tipo de infracción.";

                declaracion.NumeroExpediente = GenerarNumeroExpediente();

                declaraciones.Add(declaracion);

                return $"Se guardó el expediente {declaracion.NumeroExpediente} correctamente.";
            }
            catch (Exception ex)
            {
                return $"Error al guardar: {ex.Message}";
            }
        }

        private string GenerarNumeroExpediente()
        {
            contadorExpediente++;
            string numero = $"EXP-{contadorExpediente:0000}";

            // Validación extra: por si alguna vez se resetea el contador
            // y coincide con uno ya usado, seguimos incrementando.
            while (declaraciones.Any(d => d.NumeroExpediente == numero))
            {
                contadorExpediente++;
                numero = $"EXP-{contadorExpediente:0000}";
            }

            return numero;
        }

        public List<DeclaracionSancionada> Consultar()
        {
            return declaraciones;
        }

        public DeclaracionSancionada BuscarPorId(string id)
        {
            throw new NotImplementedException();
        }

        public bool Eliminar(DeclaracionSancionada declaracion)
        {
            if (declaracion == null)
                return false;

            return declaraciones.Remove(declaracion);
        }
        public DeclaracionSancionada BuscarPorExpediente(string numeroExpediente)
        {
            return declaraciones.FirstOrDefault(d => d.NumeroExpediente == numeroExpediente);
        }

        public void Actualizar(DeclaracionSancionada declaracion)
        {
            throw new NotImplementedException();
        }
    }
}
