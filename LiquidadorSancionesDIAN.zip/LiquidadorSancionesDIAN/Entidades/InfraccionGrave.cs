﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class InfraccionGrave : InfraccionAduanera
    {
        public override decimal MultiplicadorSMLMV => 15m;
        public override string EntidadRecaudadora => "Dirección Seccional de Aduanas";
    }
}