﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class InfraccionAduanera
    {
        // Cada subclase define cuántos SMLMV vale su sanción
        public abstract decimal MultiplicadorSMLMV { get; }

        // Cada subclase define ante quién se paga
        public abstract string EntidadRecaudadora { get; }

        // Por defecto el descuento por pronto pago es 40%,
        // pero se puede sobreescribir (ej: Contrabando = 25%)
        public virtual decimal PorcentajeDescuento => 0.40m;

        // El recargo por mora es fijo para todas: 20%
        public const decimal PorcentajeRecargo = 0.20m;

        public const decimal SMLMV = 1750905m;

        public decimal CalcularValorBase()
        {
            return MultiplicadorSMLMV * SMLMV;
        }

        // Devuelve el porcentaje de ajuste aplicado: negativo = descuento,
        // positivo = recargo, 0 = sin ajuste
        public decimal CalcularAjuste(int diasHabiles)
        {
            if (diasHabiles <= 5)
                return -PorcentajeDescuento;

            if (diasHabiles > 30)
                return PorcentajeRecargo;

            return 0m;
        }

        public decimal CalcularValorAPagar(int diasHabiles)
        {
            decimal valorBase = CalcularValorBase();
            decimal ajuste = CalcularAjuste(diasHabiles);
            return valorBase + (valorBase * ajuste);
        }
    }
}

