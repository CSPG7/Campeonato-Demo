﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class InfraccionGravisima : InfraccionAduanera
    {
        public override decimal MultiplicadorSMLMV => 30m;
        public override string EntidadRecaudadora => "DIAN Nivel Central";
    }
}