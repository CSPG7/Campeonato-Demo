﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class InfraccionContrabando : InfraccionAduanera
    {
        public override decimal MultiplicadorSMLMV => 60m;
        public override string EntidadRecaudadora => "Fondo Anti-Evasión";
        public override decimal PorcentajeDescuento => 0.25m;
    }
}
