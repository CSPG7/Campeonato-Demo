﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class InfraccionLeve : InfraccionAduanera
    {
        public override decimal MultiplicadorSMLMV => 8m;
        public override string EntidadRecaudadora => "Dirección Seccional de Aduanas";
    }
}
