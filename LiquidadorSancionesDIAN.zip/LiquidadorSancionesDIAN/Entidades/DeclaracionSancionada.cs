﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DeclaracionSancionada
    {
        public string NumeroExpediente { get; set; }
        public string NIT { get; set; }
        public string RazonSocial { get; set; }
        public InfraccionAduanera TipoInfraccion { get; set; }
        public string NumeroDeclaracionImportacion { get; set; }
        public int DiasHabilesTranscurridos { get; set; }

        
        public decimal ValorBase => TipoInfraccion.CalcularValorBase();

        public decimal Ajuste => TipoInfraccion.CalcularAjuste(DiasHabilesTranscurridos);

        public decimal ValorAPagar => TipoInfraccion.CalcularValorAPagar(DiasHabilesTranscurridos);

        public string EntidadRecaudadora => TipoInfraccion.EntidadRecaudadora;
    }
}
