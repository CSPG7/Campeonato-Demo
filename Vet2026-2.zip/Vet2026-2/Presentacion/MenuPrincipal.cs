﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class MenuPrincipal
    {
        public void Menu()
        {
            int op;
            do
            {
                Console.Clear();
                Console.SetCursorPosition(10, 3); Console.Write("MENU PRINCIPAL");
                Console.SetCursorPosition(10, 5); Console.Write("1. Gestion Raza");
                Console.SetCursorPosition(10, 7); Console.Write("2. Gestion Mascota"); 
                Console.SetCursorPosition(10, 10); Console.Write("0. Salir");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1:
                        new VistaRazas().MenuRazas();
                        break;
                    case 2:
                        new VistaMascota().MenuMascota();
                        break;
                    case 0:
                        return;
                        
                    default:
                        break;
                }
            } while (true);
        }

    }
}
