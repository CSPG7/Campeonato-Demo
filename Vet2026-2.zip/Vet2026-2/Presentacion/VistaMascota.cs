﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class VistaMascota
    {
        //ServicioRaza

        public void MenuMascota()
        {
            int op;
            do
            {
                Console.Clear();
                Console.SetCursorPosition(10, 3); Console.Write("MENU DE GESTION DE MASCOTA");
                Console.SetCursorPosition(10, 5); Console.Write("1. Guardar");
                Console.SetCursorPosition(10, 7); Console.Write("2. Consultar");
                Console.SetCursorPosition(10, 9); Console.Write("3. Eliminar");
                Console.SetCursorPosition(10, 11); Console.Write("4. Actualizar");
                Console.SetCursorPosition(10, 15); Console.Write("0. Salir");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1:
                        Guardar();
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    default:
                        break;
                }
            } while (true);
        }

        private void Guardar()
        {
            Raza raza = new Raza();
            Console.Clear();
            Console.SetCursorPosition(10, 5); Console.Write("id: ");
            Console.SetCursorPosition(13, 5); raza.Id = Console.ReadLine();
            Console.SetCursorPosition(10, 7); Console.Write("nombre: ");
            Console.SetCursorPosition(19, 7); raza.Id = Console.ReadLine();
            //llamar logica
            Console.ReadKey();
        }
    }
}
