﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class VistaRazas
    {
        ServicioRaza servicio;
        public VistaRazas()
        {
            servicio= new ServicioRaza();
        }
        public void MenuRazas()
        {
            int op;
            do
            {
                Console.Clear();
                Console.SetCursorPosition(10, 3); Console.Write("GESTION DE RAZA");
                Console.SetCursorPosition(10, 5); Console.Write("1. Guardar");
                Console.SetCursorPosition(10, 7); Console.Write("2. Consultar");
                Console.SetCursorPosition(10, 9); Console.Write("3. Eliminar");
                Console.SetCursorPosition(10, 11); Console.Write("4. Actualizar");
                Console.SetCursorPosition(10, 15); Console.Write("0. Salir");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1:
                        //CargarRazas();
                        Guardar();
                        break;
                    case 2:
                        Consultar();
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    default:
                        break;
                }
            } while (true);
        }

        private void Consultar()
        {
            int i =0;
            Console.Clear();
            Console.SetCursorPosition(10, 5); Console.Write("ID");
            Console.SetCursorPosition(14, 5); Console.Write("NOMBRE");

           foreach (var item in servicio.Consultar())
            {
                Console.SetCursorPosition(10, 7+i); Console.Write(item.Id);
                Console.SetCursorPosition(14, 7+i); Console.Write(item.Nombre);
                i += 1;
            }
            Console.ReadKey();
        }
        

        private void Guardar()
        {
            Raza raza = new Raza();
            Console.Clear();
            Console.SetCursorPosition(10, 5); Console.Write("id: ");
            Console.SetCursorPosition(13, 5); raza.Id = Console.ReadLine();
            Console.SetCursorPosition(10, 7); Console.Write("nombre: ");
            Console.SetCursorPosition(19, 7); raza.Nombre = Console.ReadLine();
            var mensaje = servicio.Guardar(raza);
            Console.Clear();
            Console.SetCursorPosition(10, 7); Console.Write(mensaje);
            
            Console.ReadKey();
        }

        public void CargarRazas()
        {
            List<Raza> razas = new List<Raza>
            {
                new Raza { Id = "1", Nombre = "Labrador Retriever" },
                new Raza { Id = "2", Nombre = "Pastor Alemán" },
                new Raza { Id = "3", Nombre = "Golden Retriever" },
                new Raza { Id = "4", Nombre = "Bulldog" },
                new Raza { Id = "5", Nombre = "Beagle" },
                //new Raza { Id = "6", Nombre = "Poodle" },
                //new Raza { Id = "7", Nombre = "Rottweiler" },
                //new Raza { Id = "8", Nombre = "Husky Siberiano" },
                //new Raza { Id = "9", Nombre = "Chihuahua" },
                new Raza { Id = "10", Nombre = "Dálmata" }
            };
        foreach (var raza in razas)
            {
                servicio.Guardar(raza);
            }

            Console.WriteLine("razas cargadas ...");
            Console.ReadKey();
        }

    }
}
