﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    internal class ServicioPropietario : IServicio<Propietario>
    {
        List<Propietario> propietarios;
        public ServicioPropietario()
        {
            propietarios= new List<Propietario>();
        }

        public void Actualizar(Propietario propietario)
        {
            throw new NotImplementedException();
        }

        public Propietario BuscarPorId(string id)
        {
            throw new NotImplementedException();
        }

        public List<Propietario> Consultar()
        {
            throw new NotImplementedException();
        }

        public bool Eliminar(Propietario propietario)
        {
            throw new NotImplementedException();
        }

        public string Guardar(Propietario entidad)
        {
            throw new NotImplementedException();
        }
    }
}
