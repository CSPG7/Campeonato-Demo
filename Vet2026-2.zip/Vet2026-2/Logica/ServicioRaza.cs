﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class ServicioRaza: IServicio<Raza>
    {

        List<Raza> razas;
        public ServicioRaza()
        {
            razas = new List<Raza>();
        }

        public void Actualizar(Raza raza)
        {
            throw new NotImplementedException();
        }

        public Raza BuscarPorId(string id)
        {
            throw new NotImplementedException();
        }

        public List<Raza> Consultar()
        {
            return razas;
        }

        public bool Eliminar(Raza raza)
        {
            throw new NotImplementedException();
        }

        public string Guardar(Raza raza)
        {
                if (raza==null || raza.Id==""|| raza.Nombre==string.Empty)
                {
                    return "Raza no Valida ...";
                }
                razas.Add(raza);
                return $"se guardo la raza {raza.Nombre} desde la logica ";
        }

    }
}
