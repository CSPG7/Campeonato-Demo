﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public interface IServicio<T>
    {
        string Guardar(T entidad);
        bool Eliminar(T propietario);
        void Actualizar(T propietario);
        List<T> Consultar();
        T BuscarPorId(string id);

    }
}
