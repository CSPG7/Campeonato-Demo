﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    internal class ServicioMascota : IServicio<Mascota>
    {
        List<Mascota> mascotas;

        public ServicioMascota()
        {
            mascotas = new List<Mascota>();
        }

        public void Actualizar(Mascota mascota)
        {
            throw new NotImplementedException();
        }

        public Mascota BuscarPorId(string id)
        {
            throw new NotImplementedException();
        }

        public List<Mascota> Consultar()
        {
            throw new NotImplementedException();
        }

        public bool Eliminar(Mascota mascota)
        {
            throw new NotImplementedException();
        }

        public string Guardar(Mascota mascota)
        {
            if (mascota == null || mascota.Id == "" || mascota.Nombre == string.Empty)
            {
                return "Mascota no Valida ...";
            }
            mascotas.Add(mascota);
            return $"se guardo la Mascota {mascota.Nombre} desde la logica ";
        }
    }
}