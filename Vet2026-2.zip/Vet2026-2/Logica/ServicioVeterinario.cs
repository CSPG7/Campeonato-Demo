﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class ServicioVeterinario : IServicio<Veterinario>
    {
        public void Actualizar(Veterinario propietario)
        {
            throw new NotImplementedException();
        }

        public Veterinario BuscarPorId(string id)
        {
            throw new NotImplementedException();
        }

        public List<Veterinario> Consultar()
        {
            throw new NotImplementedException();
        }

        public bool Eliminar(Veterinario propietario)
        {
            throw new NotImplementedException();
        }

        public string Guardar(Veterinario entidad)
        {
            throw new NotImplementedException();
        }
    }
}
