﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Veterinario : persona
    {
        public override int Edad()
        {
            throw new NotImplementedException();
        }
    }
}
