﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Mascota
    {
        public Mascota(string id, string nombre, DateTime fechaNacimiento, Raza raza)
        {
            Id = id;
            Nombre = nombre;
            FechaNacimiento = fechaNacimiento;
            AsignarRaza(raza);
        }

        public string Id { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public Raza Raza { get; private set; }

        public void AsignarRaza(Raza raza)
        {
            if (raza == null) throw new ArgumentNullException("LA RAZA NO PUEDE SER NULA");
            Raza = raza;
        }

        public string Edad()
        {
            return "AÑO: | MES: | DIA:";
        }


    }
}
