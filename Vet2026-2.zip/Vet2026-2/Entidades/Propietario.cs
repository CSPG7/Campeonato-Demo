﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Propietario : persona
    {

        public override int Edad()
        {
            return DateTime.Now.Year - FechaDeNacimiento.Year;
        }

        public List <Mascota>MisMascotas { get; private set; }=new List<Mascota>();
        public void AgregarMascota(Mascota mascota)
        {
            if (mascota==null)
            {
                return;
            }

            if (MascotaExiste(mascota))
            {
                return;
            }
            MisMascotas.Add(mascota);
        }

        private bool MascotaExiste(Mascota mascota)
        {
            foreach(var item in MisMascotas)
            {
                if (mascota.Id==item.Id)
                {
                    return true;
                }
                
            }

            return false;
        }
    }
}
